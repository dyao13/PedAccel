#' Vector of X, Y, Z, and maybe time
#'
#'
#' @format A vector with 3 or 4 elements, which are:
#' \describe{
#' \item{X}{value to extract X column}
#' \item{Y}{value to extract Y column}
#' \item{Z}{value to extract Y column}
#' \item{time}{value to extract time column}
#' }
"xyz"

#' @rdname xyz
"xyzt"

#' @rdname xyz
"txyz"
