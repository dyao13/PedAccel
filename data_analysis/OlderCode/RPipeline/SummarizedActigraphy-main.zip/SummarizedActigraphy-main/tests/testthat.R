library(testthat)
library(SummarizedActigraphy)

test_check("SummarizedActigraphy")
